export type GameRound = {
    Xpossition: number;
    Ypossition: number;
    Letter: string;
}


export type GameRounds = {
    rounds: GameRound[];
}
