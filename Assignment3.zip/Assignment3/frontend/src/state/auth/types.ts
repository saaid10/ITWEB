export type authReducerContext = {
    isLoggedIn: boolean;
}



