export const SET_N_BACK = 'SET_N_BACK';
export const SET_IS_RUNNING = 'SET_IS_RUNNING';
export const ADD_TO_SAME_LETTER = 'ADD_TO_SAME_LETTER';
export const ADD_TO_SAME_LOCATION = 'ADD_TO_SAME_LOCATION';
export const CLEAR_SCORE = "CLEAR_SCORE";

