
export const gameLength: number = 24;
export const secondsBetweenLetters: number = 3;
export const letterViewTimeSeconds: number = 1;