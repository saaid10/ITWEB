import React from 'react'

import { DualNBack } from '../dual-n-back';

function Game() {
    return (
        <DualNBack/>
    )
}


export default Game

